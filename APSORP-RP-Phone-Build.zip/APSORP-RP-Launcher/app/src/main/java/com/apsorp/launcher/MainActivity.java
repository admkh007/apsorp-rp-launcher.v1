package com.apsorp.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String SAMP_PACKAGE = "com.sampmobilerp.game";
    private EditText playerName;
    private SharedPreferences prefs;
    private final int pink = Color.rgb(239, 83, 168);
    private final int dark = Color.rgb(25, 14, 27);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("apsorp", MODE_PRIVATE);
        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{dark, Color.rgb(55, 20, 48)}));

        TextView title = new TextView(this);
        title.setText("APSORP RP"); title.setTextColor(pink); title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());
        TextView subtitle = new TextView(this);
        subtitle.setText("P I N K   E D I T I O N"); subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(12); subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = matchWrap(); subP.bottomMargin = dp(36); root.addView(subtitle, subP);

        label(root, "PLAYER NAME");
        playerName = new EditText(this); playerName.setSingleLine(true);
        playerName.setTextColor(Color.WHITE); playerName.setHintTextColor(0xFFBBA8B8);
        playerName.setHint("Enter your player name"); playerName.setText(prefs.getString("name", "Yin_fang"));
        playerName.setPadding(dp(14), 0, dp(14), 0); playerName.setTextSize(16);
        playerName.setBackground(round(Color.rgb(54, 34, 52), dp(12), 0xFF8B416F));
        LinearLayout.LayoutParams inputP = matchWrap(); inputP.height = dp(54); inputP.bottomMargin = dp(24);
        root.addView(playerName, inputP);

        label(root, "APSORP ROLEPLAY SERVER");
        TextView server = new TextView(this); server.setText("15.235.160.89 : 62121");
        server.setTextColor(Color.WHITE); server.setTextSize(17); server.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams serverP = matchWrap(); serverP.height = dp(52); serverP.bottomMargin = dp(28);
        server.setBackground(round(Color.rgb(54, 34, 52), dp(12), 0)); root.addView(server, serverP);

        Button connect = new Button(this); connect.setText("LAUNCH SA-MP"); connect.setTextColor(Color.WHITE);
        connect.setTextSize(16); connect.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        connect.setBackground(round(pink, dp(14), 0));
        LinearLayout.LayoutParams btnP = matchWrap(); btnP.height = dp(58); root.addView(connect, btnP);
        connect.setOnClickListener(v -> launchSamp());

        TextView note = new TextView(this);
        note.setText("This opens SA-MP Mobile. Select your APSORP RP server there to connect.");
        note.setTextColor(0xFFD9C5D3); note.setTextSize(12); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteP = matchWrap(); noteP.topMargin = dp(22); root.addView(note, noteP);
        setContentView(root);
    }

    private void launchSamp() {
        String name = playerName.getText().toString().trim();
        if (name.isEmpty()) { playerName.setError("Enter a player name"); return; }
        prefs.edit().putString("name", name).apply();
        Intent launch = getPackageManager().getLaunchIntentForPackage(SAMP_PACKAGE);
        if (launch == null) {
            Toast.makeText(this, "SA-MP Mobile is not installed.", Toast.LENGTH_LONG).show();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
        Toast.makeText(this, "SA-MP opened. Choose APSORP RP to connect.", Toast.LENGTH_LONG).show();
    }
    private void label(LinearLayout root, String value) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(pink);
        t.setTextSize(12); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(8); root.addView(t, p);
    }
    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
